package com.codelab.basiclayouts.data

import android.graphics.drawable.Icon
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Spa
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.DisabledByDefault
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.ui.graphics.vector.ImageVector
import com.codelab.basiclayouts.R

/**
 * A data class to represent the information presented in the dog card
 */
data class Dog(
    val icon : ImageVector,
    @DrawableRes val imageResourceId: Int,
    @StringRes val name: Int,
    val age: String,
    @StringRes val questions: Int
)

val dogs = listOf(
    Dog(Icons.Filled.AccountCircle, R.drawable.jojiuser, R.string.dog_name_1, "Our initial target audience was people with impaired vision, however anyone can use Global Vision!", R.string.dog_description_1),
    Dog(Icons.Filled.Timer, R.drawable.clock, R.string.dog_name_2, "Global Vision was created in 2023", R.string.dog_description_2),
    Dog(Icons.Default.Biotech, R.drawable.tech, R.string.dog_name_3, "Global Vision uses an Image API that was trained via TensorFlow", R.string.dog_description_3),
    Dog(Icons.Filled.VerifiedUser, R.drawable.add, R.string.dog_name_4, "Its simple, when opening the app, navigate to the sign up page and enter your details to create a new user", R.string.dog_description_4),
    Dog(Icons.Filled.PhotoAlbum, R.drawable.camera, R.string.dog_name_5, "Click the bottom navigation card, and add your photo to the specific directory", R.string.dog_description_5),
    Dog(Icons.Filled.TextFields, R.drawable.tts, R.string.dog_name_6, "The text to speech feature is on by default", R.string.dog_description_6),
    Dog(Icons.Filled.DisabledByDefault, R.drawable.offfer, R.string.dog_name_7, "To turn off the text-to-speech feature, open the menu on the home page, click settings and turn the text-to-speech off", R.string.dog_description_7),
    Dog(Icons.Filled.AccountCircle, R.drawable.cody, R.string.dog_name_8, "Global Vision was made in a span of 4 months", R.string.dog_description_8),
    Dog(Icons.Filled.AccountCircle, R.drawable.tooly, R.string.dog_name_9, "Global vision uses Kotlin and the Jetpack Compose Android Studio toolkit", R.string.dog_description_9)
)
