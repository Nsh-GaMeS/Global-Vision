package com.codelab.basiclayouts;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

public class ImageClassificationActivity extends MLImageHelperActivity implements TextToSpeech.OnInitListener{
    private ImageLabeler imageLabeler;
    private TextToSpeech textToSpeech;

    public static int imageCounter = 10;

    public List<Bitmap> inputImages = new ArrayList<>();









    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.recent_images);
        imageCounter++;
        super.onCreate(savedInstanceState);
        textToSpeech = new TextToSpeech(this, this);


        imageLabeler = ImageLabeling.getClient(new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(0.7f)
                .build());
    }
    @Override
    protected void runDetection(Bitmap bitmap) {
        Thread detectionThread = new Thread(() -> {

        imageCounter++;

        getTitleTextView().setText("");

        getCamView().setVisibility(View.INVISIBLE);

        AtomicInteger counter = new AtomicInteger(0);

        InputImage inputImage = InputImage.fromBitmap(bitmap, 0);
        inputImages.add(bitmap);
        imageLabeler.process(inputImage).addOnSuccessListener(imageLabels -> {
           StringBuilder sb = new StringBuilder();
           for (ImageLabel label : imageLabels) {

               int confidencePercentage = (int) (label.getConfidence() * 100);
               sb.append(label.getText()).append(": ").append(confidencePercentage).append("%\n");

               if (counter.incrementAndGet() >= 3) {
                   break; // Exit the loop after three iterations
               }
           }
           if (imageLabels.isEmpty()) {
               getOutputTextView().setText("Could not classify!!");
               speak("Could not Classify");

           } else {
               getOutputTextView().setText(sb.toString());
               speak(sb.toString());
           }
        }).addOnFailureListener(e -> {
            e.printStackTrace();
        });
        });
        detectionThread.start();

    }

    public List<Bitmap> getInputImages(){
        return inputImages;
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = textToSpeech.setLanguage(Locale.getDefault());

            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                System.out.println("Language not supported");
            }
        } else {
            System.out.println("Initialization failed");
        }
    }

    private void speak(String message) {
        textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }

    public int getImageCounter() {
        return imageCounter;
    }


}
