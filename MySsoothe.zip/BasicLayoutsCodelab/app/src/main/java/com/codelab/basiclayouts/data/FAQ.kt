package com.codelab.basiclayouts.data

data class FAQ(val question: String, val answer: String)