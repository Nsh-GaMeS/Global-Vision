package com.codelab.basiclayouts.data

data class Item(val imageRes: Int, val text: String)