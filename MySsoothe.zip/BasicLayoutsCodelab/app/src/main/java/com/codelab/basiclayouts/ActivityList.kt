package com.codelab.basiclayouts

class ActivityList {
}